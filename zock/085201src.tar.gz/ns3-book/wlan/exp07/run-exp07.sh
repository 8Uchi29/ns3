#!/bin/sh

echo ./waf --run "exp07-wimax-multicast --duration=100"
./waf --run "exp07-wimax-multicast --duration=100"
