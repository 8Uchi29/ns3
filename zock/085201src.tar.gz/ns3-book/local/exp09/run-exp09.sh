#!/bin/sh

./waf --run "exp09-ipv6-basic --showIP=1"

./waf --run "exp09-ipv6-basic --showRT=1"
