#!/bin/sh

./waf --run exp10-switchedNetwork --vis
