1. Execution (Congestion Window only)
  % sh run-exp08.sh
  % gnuplot plot-exp08.pl

2. Execution (Congestion Window and throughputs)
  % sh run-exp08-with-throughput.sh
  % sh show-graph.sh
