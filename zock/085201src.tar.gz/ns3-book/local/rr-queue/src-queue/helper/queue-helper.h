/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
#ifndef __QUEUE_HELPER_H__
#define __QUEUE_HELPER_H__

#include "ns3/queue.h"

namespace ns3 {

/* ... */

}

#endif /* __QUEUE_HELPER_H__ */

